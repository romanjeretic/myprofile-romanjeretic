
[@Aldiskatel preset](https://github.com/Toxblh/MTMR-presets/raw/master/Aldiskatel/items.json)
![](https://github.com/aldiskatel/MTMR-presets/raw/master/Aldiskatel/Touchbar.png)
