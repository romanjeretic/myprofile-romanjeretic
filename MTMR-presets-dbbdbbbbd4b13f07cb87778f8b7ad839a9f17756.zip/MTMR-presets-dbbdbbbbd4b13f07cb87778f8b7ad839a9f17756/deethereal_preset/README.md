**This preset consists of:**  
 Network Speed,  
 Spotify current track,  
 decrease brightness,  
 increase brightness,  
 buttons to switch to the previous/next track in your playlist,  
 "coffee break"-button(turns off your display),  
 mute button, volume control,  
 current battery status,  
 local time.  
![alt text](https://raw.githubusercontent.com/deethereal/MTMR-presets/master/deethereal_preset/touch_screen.png)
